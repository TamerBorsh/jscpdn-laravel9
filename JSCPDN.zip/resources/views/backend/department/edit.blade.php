@extends('backend.layouts.master')
@section('title')
    تعديل بيانات القسم | {{ auth()->user()->name }}
@endsection
@section('content')
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('dashboard.index') }}">الرئيسية<i
                                        class="dripicons-chevron-left"></i></a></li>
                            <li class="breadcrumb-item"><a href="{{ route('departments.index') }}">الأقسام<i
                                        class="dripicons-chevron-left"></i></a></li>
                            <li class="breadcrumb-item">تحديث بيانات القسم</li>
                        </ol>
                    </div>
                    <h4 class="page-title">تحديث بيانات القسم</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <div class="row">

                            <form id="addDataForm" action="" method="post" enctype="multipart/form-data">
                                @csrf
                                @method('put')

                                <div class="row">

                                    <div class="mb-3 col-md-12">
                                        <label for="name" class="form-label">الاسم</label>
                                        <input type="text" class="form-control" id="name" name="name"
                                            value="{{ $department->name }}">
                                    </div>


                                    <div class="mb-3 col-md-6">
                                        <label for="status_" class="form-label">القسم</label>
                                        <select class="form-select" id="circle_id" name="circle_id">
                                            @forelse ($circles as $circle)
                                                <option value="{{ $circle->id }}"
                                                    {{ $circle->id == $department->circle_id ? 'selected' : '' }}>
                                                    {{ $circle->name }}</option>
                                            @empty
                                                <option>لا يوجد بيانات</option>
                                            @endforelse

                                        </select>
                                    </div>

                                    <div class="mb-3 col-md-6">
                                        <label for="status_" class="form-label">الحالة</label>
                                        <select class="form-select" id="status_" name="status_">
                                            <option value="1" @if ($department->department_status == 1) selected @endif>نشط
                                            </option>
                                            <option value="0" @if ($department->department_status == 0) selected @endif>غير نشط
                                            </option>
                                        </select>
                                    </div>

                                </div>

                                <button type="submit" class="btn btn-primary" id="btnSubmit"
                                    style=" margin-top: 20px; padding: 6px 25px; ">حفظ</button>
                            </form>
                        </div>
                        <!-- end row -->

                    </div> <!-- end card-body -->
                </div> <!-- end card-->
            </div> <!-- end col-->
        </div>
        <!-- end row-->

    </div>
@endsection

@section('script')
    <script>
        //create
        $("#addDataForm").on('submit', function(e) {
            e.preventDefault();
            var formData = new FormData($('#addDataForm')[0]);
            axios({
                    method: 'post',
                    url: "{{ route('departments.update', $department->id) }}",
                    data: formData
                })
                .then(function(response) {
                    Toast.fire({
                        icon: 'success',
                        title: response.data.message
                    })
                })
                .catch(function(error) {
                    // console.log(error);
                    if (error.response.status == 422) {
                        var object = error.response.data.errors;
                        for (const key in object) {
                            var message = object[key][0]
                            break;
                        }
                        toastr.error(message);
                    } else {
                        toastr.error(error.response.data.message);
                    }
                });
        });
    </script>
@endsection
