<?php

namespace App\Http\Controllers\Problem;

use App\Http\Controllers\Controller;
use App\Http\Requests\Problem\StoreRequest;
use App\Http\Requests\Problem\UpdateRequest;
use App\Models\Admin;
use App\Models\Problem;
use App\Traits\ImageTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Symfony\Component\HttpFoundation\Response;

class ProblemController extends Controller
{
    use ImageTrait;

    public function __construct()
    {
        $this->middleware('auth:admin,web');
        $this->authorizeResource(Problem::class, 'problem');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $request = request();

        if (Auth::guard('web')->check()) {
            $data = Problem::with(['user', 'admin'])
                ->select('id', 'title', 'category', 'importance', 'photo', 'content', 'status', 'user_id', 'admin_id', 'reply', 'number_call', 'created_at')
                ->whereUser_id(auth('web')->user()->id)
                ->orderByDesc('id')->paginate(page_numbering_back);
        } else {
            $query = Problem::query();
            if ($search = $request->query('search')) {
                $query->where('title', 'like', "%{$search}%");
            }
            if ($status = $request->query('status')) {
                $query->whereStatus($status);
            }
            if ($category = $request->query('category')) {
                $query->whereCategory($category);
            }
            if ($importance = $request->query('importance')) {
                $query->whereImportance($importance);
            }

            $data = $query->whereAdmin_id(auth('admin')->user()->id)->orderByDesc('id')->paginate(page_numbering_back);
        }
        // return response()->json($data);
        return response()->view('backend.problem.index', ['problems' => $data]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $admin = Admin::select('id', 'name')->where('id', '!=', '1')->get();
        return response()->view('backend.problem.create', ['admins' => $admin]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreRequest $request)
    {
        if ($request->hasFile('photo_main') && request('photo_main') != null) {
            $request->photo                     = $this->SaveImage($request->file('photo_main'), 'images/uploads/problems/');
        }

        $request->merge([
            'user_id'   => auth()->user()->id,
            'photo'     => $request->photo
        ]);

        $data = $request->only(['title', 'category', 'content', 'admin_id', 'user_id', 'photo', 'number_call']);

        $problem = Problem::create($data);

        if ($problem) {
            return response()->json(['message' => $problem ? 'تم الحفظ' : 'هناك خطأ ما'], $problem ? Response::HTTP_CREATED : Response::HTTP_BAD_REQUEST);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Problem  $problem
     * @return \Illuminate\Http\Response
     */
    public function show(Problem $problem)
    {
        $admin = Admin::select('id', 'name')->get();
        // return response()->json($problem);
        // $problem = $problem->whereAdmin_id(auth('admin')->user()->id);

        return response()->view('backend.problem.show', ['problem' => $problem, 'admins' => $admin]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Problem  $problem
     * @return \Illuminate\Http\Response
     */
    public function edit(Problem $problem)
    {
        $admin = Admin::select('id', 'name')->get();
        if ($problem->admin_id != auth('admin')->user()->id) {
            return abort('404');
        }
        return response()->view('backend.problem.edit', ['problem' => $problem, 'admins' => $admin]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Problem  $problem
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateRequest $request, Problem $problem)
    {
        $data = $request->only(['status', 'importance', 'reply']);

        $isSave = $problem->update($data);
        if ($isSave) {
            return response()->json(['message' => $isSave ? 'تم الحفظ' : 'هناك خطأ ما'], $isSave ? Response::HTTP_CREATED : Response::HTTP_BAD_REQUEST);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Problem  $problem
     * @return \Illuminate\Http\Response
     */
    public function destroy(Problem $problem)
    {
        if ($problem->admin_id != auth('admin')->user()->id) {
            return abort('404');
        }
        $isDelete = $problem->delete();
        $file_path  = public_path('images/uploads/problems/') . $problem->photo;
        if (File::exists($file_path)) {
            File::delete($file_path);
        }
        return response()->json([
            'icon'  =>  $isDelete ? 'success' : 'error',
            'title' =>  $isDelete ? 'تم الحذف بنجاح' : 'فشل الحذف',
        ], $isDelete ? Response::HTTP_OK : Response::HTTP_BAD_REQUEST);
    }
}
