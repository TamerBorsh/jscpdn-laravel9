<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class PermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Permission::create(['name' => 'Read-Admins',            'guard_name' => 'admin']);
        Permission::create(['name' => 'Create-Admin',           'guard_name' => 'admin']);
        Permission::create(['name' => 'Update-Admin',           'guard_name' => 'admin']);
        Permission::create(['name' => 'Delete-Admin',           'guard_name' => 'admin']);

        Permission::create(['name' => 'Read-Users',             'guard_name' => 'admin']);
        Permission::create(['name' => 'Create-User',            'guard_name' => 'admin']);
        Permission::create(['name' => 'Update-User',            'guard_name' => 'admin']);
        Permission::create(['name' => 'Delete-User',            'guard_name' => 'admin']);

        Permission::create(['name' => 'Read-Problems',          'guard_name' => 'admin']);
        Permission::create(['name' => 'Create-Problem',         'guard_name' => 'admin']);
        Permission::create(['name' => 'Update-Problem',         'guard_name' => 'admin']);
        Permission::create(['name' => 'Delete-Problem',         'guard_name' => 'admin']);

        Permission::create(['name' => 'Read-Problems',          'guard_name' => 'web']);
        Permission::create(['name' => 'Create-Problem',         'guard_name' => 'web']);

        Permission::create(['name' => 'Read-Permissions',       'guard_name' => 'admin']);
        Permission::create(['name' => 'Create-Permission',      'guard_name' => 'admin']);
        Permission::create(['name' => 'Update-Permission',      'guard_name' => 'admin']);
        Permission::create(['name' => 'Delete-Permission',      'guard_name' => 'admin']);

        Permission::create(['name' => 'Read-Roles',             'guard_name' => 'admin']);
        Permission::create(['name' => 'Create-Role',            'guard_name' => 'admin']);
        Permission::create(['name' => 'Show-Role',              'guard_name' => 'admin']);
        Permission::create(['name' => 'Update-Role',            'guard_name' => 'admin']);
        Permission::create(['name' => 'Delete-Role',            'guard_name' => 'admin']);


        Role::create(['name' => 'Admin',            'guard_name' => 'admin']);
        Role::create(['name' => 'mun',              'guard_name' => 'admin']);
        Role::create(['name' => 'client',           'guard_name' => 'web']);

    }
}
